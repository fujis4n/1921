import sqlite3
from bs4 import BeautifulSoup
import requests
import datetime

connection = sqlite3.connect("Tmp.sl3", 5)
cur = connection.cursor()
response = requests.get("https://www.meteoprog.ua/ua/weather/Chercasy/")
if response.status_code == 200:
    soup = BeautifulSoup(response.text, features = "html.parser")
    soup_list = soup.find_all("div", {"class" : "today-temperature"})
for elem in soup_list:
    text1 = elem.text
    text2 = datetime.date.today()
# cur.execute("CREATE TABLE temperature(Tmp TEXT, Data TEXT);")
cur.execute(f"INSERT INTO temperature (Data) VALUES ('{text2}')")
cur.execute(f"INSERT INTO temperature (Tmp) VALUES ('{text1}')")
connection.commit()
cur.execute("SELECT rowid, Tmp FROM temperature;")
cur.execute("SELECT rowid, Data FROM temperature;")
connection.commit()
connection.close()
